from flask import Flask, render_template, request

app = Flask(__name__)

class Todo:
    def __init__(self):
        self.todolist = []

    def add_todo(self, task):
        self.todolist.append(task)

    def edit_todo(self, index, task):
        self.todolist[index] = task

    def delete_todo(self, index):
        del self.todolist[index]

    def mark_done_todo(self, index):
        self.todolist.pop(index)

todo_app = Todo()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if request.form['submit'] == 'Add':
            task = request.form['task']
            todo_app.add_todo(task)
        elif request.form['submit'] == 'Edit':
            index = int(request.form['index'])
            task = request.form['task']
            todo_app.edit_todo(index, task)
        elif request.form['submit'] == 'Delete':
            index = int(request.form['index'])
            todo_app.delete_todo(index)
        elif request.form['submit'] == 'Mark as done':
            index = int(request.form['index'])
            todo_app.mark_done_todo(index)

    return render_template('index.html', todolist=todo_app.todolist)

if __name__ == '__main__':
    app.run(debug=True)
